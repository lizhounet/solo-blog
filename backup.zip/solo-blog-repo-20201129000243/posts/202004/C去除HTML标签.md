title: C#去除HTML标签
date: '2020-04-01 13:04:28'
updated: '2020-04-15 17:23:27'
tags: [C#]
permalink: /articles/2020/04/01/1585717468240.html
---
```
public static string ReplaceHtmlTag(string html, int length = 0)
{
    string strText = System.Text.RegularExpressions.Regex.Replace(html, "<[^>]+>", "");
    strText = System.Text.RegularExpressions.Regex.Replace(strText, "&[^;]+;", "");
    if (length > 0  && strText.Length > length)
        return strText.Substring(0, length);
    return strText;
}
```
