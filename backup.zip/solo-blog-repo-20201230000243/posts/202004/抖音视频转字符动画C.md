title: 抖音视频转字符动画(C#)
date: '2020-04-01 15:23:25'
updated: '2020-04-01 15:23:25'
tags: [视频, C#]
permalink: /articles/2020/04/01/1585725805262.html
---
某日刷抖音看到了别人做的视频转字符动画,感觉挺厉害也挺有意思,就决定自己实现了一下;
### 实现思路：

#### 第一步: 把视频文件每一帧截取成图片
截取视频每一帧图片用到一个强大的视频处理软件(ffmpeg);以下为主要代码：
```
  /// <summary>
  /// 使用ffMpeg.exe截取视频图片（第一帧）
  /// </summary>
  /// <param name="vedioPath">视频路径</param>
  /// <param name="saveImgWidth">保存的图片宽度</param>
  /// <param name="saveImgHeight">保存的图片高度</param>
  /// <returns>保存后的图片路径</returns>
  public static string CatchImg(string vedioPath, int saveImgWidth = 500, int saveImgHeight = 500)
    {
        string ffmpeg = AppDomain.CurrentDomain.BaseDirectory + "\\" + "ffmpeg\\ffmpeg.exe";
        if ((!System.IO.File.Exists(ffmpeg)) || (!System.IO.File.Exists(vedioPath)))
        {
            return "";
        }
        string saveImgPath = System.IO.Path.ChangeExtension(vedioPath, ".jpg");
        string saveImgSize = string.Format("{0}x{1}", saveImgWidth, saveImgHeight);
        ProcessStartInfo startInfo = new ProcessStartInfo(ffmpeg);
        startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
        //startInfo.Arguments = string.Format(" -i \"{0}\" -y -f image2 -t 0.001 -s \"{1}\" \"{2}\"", vedioPath, saveImgSize, saveImgPath);
       string imgSavePath = $"{AppDomain.CurrentDomain.BaseDirectory}temp\\Intercept";
       if (System.IO.Directory.Exists(imgSavePath))
       {
           System.IO.Directory.Delete(imgSavePath, true);//删除文件夹下面所有文件
       }
       System.IO.Directory.CreateDirectory(imgSavePath);//创建路径
       startInfo.Arguments = $" -i " + vedioPath                    //视频路径
                          + " -r 24"                               //提取图片的频率
                          + " -y -f image2 -ss " + "00:00:00"   //设置开始获取帧的视频时间
                          + " -t 01:00:00 "/*-s " + $"{saveImgSize} "*/             //设置图片的分辨率
                          + $@" {imgSavePath}\%d.jpg";  //输出的图片文件名，路径前必须有空格
       System.Diagnostics.Process.Start(startInfo);
       return imgSavePath;
  }
```
#### 第二步: 然后把图片转为字符画
以下为主要代码：
```
 /// <summary>
 /// 把图片转换为字符画
 /// </summary>
 /// <param name="bitmap"></param>
 /// <param name="rowSize"></param>
 /// <param name="colSize"></param>
 /// <param name="type"></param>
 /// <returns></returns>
 public static string Generate(Bitmap bitmap, int rowSize, int colSize, int type)
 {
     StringBuilder result = new StringBuilder();
     //var charstr=" $@B%8&WM#*oahkbdpqwmZO0QLCJUYXzcvunxrjft/\\|()1{}[]?-_+~<>i!lI;:,\"^`'.";
     //char[] charset = charstr.ToArray();
     char[] charset = { ' ', '.', ',', ':', ';', 'i', '1', 'r', 's', '5', '3', 'A', 'H', '9', '8', '&', '@', '#' };
     if (type == 1)
     {
         //charset = new char[] { '8', '9', '6', '4', '3', '5', '7', '0', '2', '1', '.',' ' };
         charset = new char[] { ' ', '.', '1', '2', '0', '7', '5', '3', '4', '6', '9', '8' };
     }
     else if (type == 2)
     {
         charset = new char[] { '丶', '卜', '乙', '日', '瓦', '車', '馬', '龠', '齱', '龖' };
     }
     int bitmapH = bitmap.Height;
     int bitmapW = bitmap.Width;
     for (int h = 0; h < bitmapH / rowSize; h++)
     {
         int offsetY = h * rowSize;
         for (int w = 0; w < bitmapW / colSize; w++)
         {
             int offsetX = w * colSize;
             float averBright = 0;
             for (int j = 0; j < rowSize; j++)
             {
                 for (int i = 0; i < colSize; i++)
                 {
                     try
                     {
                         Color color = bitmap.GetPixel(offsetX + i, offsetY + j);
                         averBright += color.GetBrightness();
                     }
                     catch (ArgumentOutOfRangeException)
                     {
                         averBright += 0;
                     }
                 }
             }
             averBright /= (rowSize * colSize);
             int index = (int)(averBright * charset.Length);
             if (index == charset.Length)
                 index--;
             result.Append(charset[charset.Length - 1 - index]);
         }
         result.Append("\r\n");
     }
     return result.ToString();
}
```
