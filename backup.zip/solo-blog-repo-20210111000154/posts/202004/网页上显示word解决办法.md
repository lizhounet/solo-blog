title: 网页上显示word解决办法
date: '2020-04-01 13:23:30'
updated: '2020-04-03 15:52:40'
tags: [网页, word]
permalink: /articles/2020/04/01/1585718610803.html
---
1.把word转换成pdf

2.网页上通过pdfobject.js 加载pdf文件(注意:pdfobject.js 不是解析pdf的插件，他只是调用浏览器自带的pdf解析，如果浏览器不支持解析pdf 则需要使用pdf.js插件解析pdf)
解决过程:

pdfobject.js 官网 [http://www.pdfobject.com/](http://www.pdfobject.com/)
记录一下主要代码：

```
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <script src="~/Framework/pdfobject.js"></script>
    <title></title>
    <style>
        .pdfobject {
            border: 1px solid #666;
        }
    </style>
</head>
<body>
    <div>
        <div id="example"></div>
    </div>
    <script>
        window.onload = function () {
            if (PDFObject.supportsPDFs) {
                PDFObject.embed("../../Content/Meeting" + "@ViewBag.filePath", "#example",{ height: "700px" });
            } else {
                alert("您的浏览器不支持pdf,请下载谷歌浏览器");
            }
        }
    </script>
</body>
</html>
```
