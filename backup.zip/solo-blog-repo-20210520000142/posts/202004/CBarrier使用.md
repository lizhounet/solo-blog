title: C# Barrier使用
date: '2020-04-01 16:04:19'
updated: '2020-04-01 16:04:19'
tags: [C#]
permalink: /articles/2020/04/01/1585728259471.html
---
Barrier  是一个对象，它可以在并行操作中的所有任务都达到相应的关卡之前，阻止各个任务继续执行。 如果并行操作是分阶段执行的，并且每一阶段要求各任务之间进行同步，则可以使用该对象。 ——MSDN

按照我的理解Barrier其实就是将多个任务同步，而同步需要一个屏障或者是关卡，那么其方法SignalAndWait()就是屏障的作用；

我们来模拟现实中例子，做火车就是很好的参照，大家知道，火车的车次有个发车点，到了那个时间点才能发车，那我们稍微修改下，人到齐后才能发车。

思路:假设三个人赶火车,三个人
```
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PLinq
{
    class Program
    {
        static Barrier gate;
        static void Main(string[] args)
        {
            try
            {
                ToStationWorkTyp1();
            }
            catch (Exception ex)
            {
                Console.WriteLine(string.Format("Exception Message:{0}", ex.Message.Trim()));
            }
            finally
            {
                Console.ReadLine();
            }
        }
        private static void ToStationWorkTyp1()
        {
            gate = new Barrier(3);
            Task _taskA = Task.Factory.StartNew(() => ToStation("PersonA"));
            Task _taskB = Task.Factory.StartNew(() => ToStation("PersonB"));
            Task _taskC = Task.Factory.StartNew(() => ToStation("PersonC"));
            Task.WaitAll(_taskA, _taskB, _taskC);
        }
        private static void ToStation(string name)
        {
            Console.WriteLine(string.Format("[{0}]到达火车站，已经上火车啦.....", name));
            gate.SignalAndWait();//三个人都上火车了之后,火车才会发车
            Console.WriteLine(string.Format("[{0}]乘坐火车离开.....", name));
        }
    }
}
```
实现效果:

![](https://qiniucdnpublic.zhouli.info//f7ad4c07-b5f4-41b6-8d19-174a1cd5ec64.png)
