title: MySQL监控全部执行过的sql语句
date: '2021-07-13 14:07:28'
updated: '2021-07-13 14:07:28'
tags: [mysql]
permalink: /articles/2021/07/13/1626156448829.html
---
先登录mysql

![](https://b3logfile.com/file/2021/07/solo-fetchupload-217783455044624851-97087798.png)

查看是否开启日志记录

```
mysql> show variables like "general_log%";
```

![](https://b3logfile.com/file/2021/07/solo-fetchupload-2937336654390083768-f3b2f041.png)

OFF 关闭

ON 开启

临时开启日志记录

```
set global general_log=’ON’
```

这时执行的所有sql都会被记录下来，但是如果重启mysql就会停止记录需要重新设置

```
mysql> exit
```

查看100行日志

```
tail -100f /data/mysql/localhost.log
```

查看全部

```
cat  /data/mysql/localhost.log
```

查看是否开启binlog

```
mysql> show variables like "log_bin";
+---------------+-------+
| Variable_name | Value |
+---------------+-------+
| log_bin       | OFF   |
+---------------+-------+
1 row in set (0.00 sec)
```

查看当前的binlog日志

show master status ;
