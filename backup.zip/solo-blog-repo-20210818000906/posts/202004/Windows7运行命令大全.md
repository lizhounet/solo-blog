title: Windows 7运行命令大全
date: '2020-04-01 13:45:40'
updated: '2020-04-01 13:45:40'
tags: [Windows]
permalink: /articles/2020/04/01/1585719940367.html
---
```
     1、cleanmgr:打开磁盘清理工具
　　 2、compmgmt.msc:计算机管理
　　 3、conf:启动系统配置实用程序
　　 4、charmap:启动字符映射表
　　 5、calc:启动计算器
　　 6、chkdsk.exe:Chkdsk磁盘检查
　　 7、cmd.exe:CMD命令提示符
　　 8、certmgr.msc:证书管理实用程序
　　 9、Clipbrd:剪贴板查看器
　　 10、dvdplay:DVD播放器
　　 11、diskmgmt.msc:磁盘管理实用程序
　　 12、dfrg.msc:磁盘碎片整理程序
　　 13、devmgmt.msc:设备管理器
　　 14、dxdiag:检查DirectX信息
　　 15、dcomcnfg:打开系统组件服务
　　 16、explorer:打开资源管理器
　　 17、eventvwr:事件查看器
　　 18、eudcedit:造字程序
　　 19、fsmgmt.msc:共享文件夹管理器
　　 20、gpedit.msc:组策略
　　 21、iexpress:工具，系统自带
　　 22、logoff:注销命令
　　 23、lusrmgr.msc:本机用户和组
　　 24、MdSched:来启动Windows内存诊断程序
　　 25、mstsc:远程桌面连接
　　 26、Msconfig.exe:系统配置实用程序
　　 27、mplayer2:简易widnowsmediaplayer
　　 28、mspaint:画图板
　　 29、magnify:放大镜实用程序
　　 30、mmc:打开控制台
　　 31、mobsync:同步命令
　　 32、notepad:打开记事本
　　 33、nslookup:网络管理的工具向导
　　 34、narrator:屏幕“讲述人”
　　 35、netstat:an(TC)命令检查接口
　　 36、OptionalFeatures：打开“打开或关闭Windows功能”对话框
　　 37、osk:打开屏幕键盘
　　 38、perfmon.msc:计算机性能监测程序
　　 39、regedt32:注册表编辑器
　　 40、rsop.msc:组策略结果集
　　 41、regedit.exe:注册表
　　 42、services.msc:本地服务设置
　　 43、sysedit:系统配置编辑器
　　 44、sigverif:文件签名验证程序
　　 45、shrpubw:创建共享文件夹
```

