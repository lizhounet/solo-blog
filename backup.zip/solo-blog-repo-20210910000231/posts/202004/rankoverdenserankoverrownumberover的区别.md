title: rank() over,dense_rank() over,row_number() over的区别
date: '2020-04-01 16:05:35'
updated: '2020-04-15 10:07:19'
tags: [sql, sqlserver, mysql]
permalink: /articles/2020/04/01/1585728335477.html
---
![](https://img.hacpai.com/bing/20180423.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

1.rank() over：查出指定条件后的进行排名。特点是，加入是对学生排名，使用这个函数，成绩相同的两名是并列，下一位同学空出所占的名次。

```
select name,subject,score,rank() over(partition by subject order by score desc) rank from student_score;
```

![](https://images2018.cnblogs.com/blog/1476885/201808/1476885-20180830090537924-678260036.png)

2.dense_rank() over：与ran() over的區别是，两名学生的成绩并列以后，下一位同学并不空出所占的名次。

```
select name,subject,score,dense_rank() over(partition by subject order by score desc) rank from student_score;
```

![](https://images2018.cnblogs.com/blog/1476885/201808/1476885-20180830090650526-424335453.png)

3.row_number() over这个函数不需要考虑是否并列，哪怕根据条件查询出来的数值相同也会进行连续排名

```
select name,subject,score,row_number() over(partition by subject order by score desc) rank from student_score;
```

![](https://images2018.cnblogs.com/blog/1476885/201808/1476885-20180830090746251-1156974345.png)

4.使用rank() over的时候，空值是最大的，如果排序字段为null,可能造成null字段排在最前面，影响排序结果。可以这样：rank() over(partition by course order by score desc nulls last)来规避这个问题。

select name,subject,score,rank() over(partition by subject order by score desc nulls last) rankfrom student_score;

![](https://images2018.cnblogs.com/blog/1476885/201808/1476885-20180830090832630-854244622.png)
