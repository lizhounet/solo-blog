title: ASP.NET Core开源地址
date: '2020-04-01 15:24:57'
updated: '2020-04-01 15:24:57'
tags: [.netcore]
permalink: /articles/2020/04/01/1585725897382.html
---
```
https://github.com/dotnet/corefx 这个是.net core的 开源项目地址

https://github.com/aspnet 这个下面是asp.net core 框架的地址，里面有很多仓库。

https://github.com/aspnet/EntityFrameworkCore  EF Core源码

https://github.com/aspnet/Configuration 配置模块源码

https://github.com/aspnet/Routing 路由模块

https://github.com/aspnet/Security 认证及授权 

https://github.com/aspnet/DependencyInjection 依赖注入

https://github.com/aspnet/HttpAbstractions 这个一定要看，有很多的一些HTTP管道的抽象接口都定义在这里

https://github.com/aspnet/Options   看名字

https://github.com/aspnet/Mvc 

https://github.com/aspnet/Hosting
```
