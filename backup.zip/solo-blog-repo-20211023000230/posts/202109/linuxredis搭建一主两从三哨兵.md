title: linux redis搭建一主两从三哨兵
date: '2021-09-28 10:37:37'
updated: '2021-09-28 11:26:28'
tags: [Redis]
permalink: /articles/2021/09/28/1632796657491.html
---
## 介绍

在 Redis 主从集群中，哨兵机制是实现主从库自动切换的关键机制，它有效地解决了主从复制模式下故障转移的这三个问题。

哨兵其实就是一个运行在特殊模式下的 Redis 进程，主从库实例运行的同时，它也在运行。哨兵主要负责的就是三个任务：监控、选主（选择主库）和通知。

哨兵的主要功能：

1. 集群监控：负责监控 Redis master 和 slave 进程是否正常工作。
2. 消息通知：如果某个 Redis 实例有故障，那么哨兵负责发送消息作为报警通知给管理员。
3. 故障转移：如果 master node 挂掉了，会自动转移到 slave node 上。
4. 配置中心：如果故障转移发生了，通知 client 客户端新的 master 地址。

PS：根据推举机制，集群中哨兵数量最好为奇数(3、5....)

## 准备环境

| IP地址         | 角色                   | Redis版本 |
| -------------- | ---------------------- | --------- |
| 127.0.0.1:6379 | redis-master，sentinel | 6.25      |
| 127.0.0.1:6380 | redis-slave1，sentinel | 6.25      |
| 127.0.0.1:6381 | redis-slave2，sentinel | 6.25      |

## 具体步骤

### 1.安装redis

安装C/C++环境
Redis编译时需要使用C/C++环境：

```
yum -y install gcc gcc-c++ make
```

下载Redis安装包

```
#创建目录
mkdir /data/redis && cd /data/redis
wget http://download.redis.io/releases/redis-6.2.5.tar.gz
```

解压Redis安装包

```
tar -zxvf redis-6.2.5.tar.gz && mv redis-6.2.5 redis6379
tar -zxvf redis-6.2.5.tar.gz && mv redis-6.2.5 redis6380
tar -zxvf redis-6.2.5.tar.gz && mv redis-6.2.5 redis6381
```

![image.png](https://b3logfile.com/file/2021/09/image-53f42e7a.png)

编译三个Redis

```
cd /data/redis/redis6379 && make
cd /data/redis/redis6380 && make
cd /data/redis/redis6381 && make
```

编译成功后**src** 目录下会出现编译后的 redis 服务程序 redis-server
![image.png](https://b3logfile.com/file/2021/09/image-e72883bd.png)

### 2.配置Redis（redis-master节点）

#### 2.1 配置redis.conf

```
cd /data/redis/redis6379
mkdir tmp
vi redis.conf
```

配置信息：

```
#表示redis允许所有地址连接。默认127.0.0.1，仅允许本地连接。
bind 0.0.0.0
#允许redis后台运行
daemonize yes
#设置redis日志存放路径
logfile "/data/redis/log/redis_6379.log"
#设置为no，允许外部网络访问
protected-mode no
#修改redis监听端口(可以自定义)
port 6379
#pid存放目录
pidfile /var/run/redis_6379.pid
#工作目录，需要创建好目录,可自定义
dir /data/redis/redis6379/tmp
#设置redis密码
requirepass 123456
#主从同步master的密码
masterauth 123456
```

#### 2.2 修改配置Sentinel(哨兵)

```
#修改Sentinel监听端口
port 26379
#允许Sentinel后台运行
daemonize yes
#设置Sentinel日志存放路径
logfile "/data/redis/log/redis_6379_sentinel.log"
#工作目录，需要创建好目录,可自定义
dir /data/redis/redis6379/tmp
#Sentinel监听redis主节点,redis01：master名称可自定义,127.0.0.1 6379 ：redis主节点IP和端口,2 ：表示多少个Sentinel认为redis主节点失效时，才算真正失效
sentinel monitor redis01 127.0.0.1 6379 2
#配置失效时间，master会被这个sentinel主观地认为是不可用的，单位毫秒   
sentinel down-after-milliseconds redis01 10000
#若sentinel在该配置值内未能完成master/slave自动切换，则认为本次failover失败。
sentinel failover-timeout redis01 60000
#在发生failover主备切换时最多可以有多少个slave同时对新的master进行同步。
sentinel parallel-syncs redis01 2
#设置连接master和slave时的密码，注意的是sentinel不能分别为master和slave设置不同的密码，因此master和slave的密码应该设置相同
sentinel auth-pass redis01 123456
```

### 3.配置Redis（redis-slave节点）

#### 3.1 redis6380

##### 3.1.1 redis6380配置redis.conf

```
cd /data/redis/redis6380
mkdir tmp
vi redis.conf
```

配置信息(和redis6379差不多，多了最后一行)：

```
#表示redis允许所有地址连接。默认127.0.0.1，仅允许本地连接。
bind 0.0.0.0
#允许redis后台运行
daemonize yes
#设置redis日志存放路径
logfile "/data/redis/log/redis_6380.log"
#设置为no，允许外部网络访问
protected-mode no
#修改redis监听端口(可以自定义)
port 6380
#pid存放目录
pidfile /var/run/redis_6380.pid
#工作目录，需要创建好目录,可自定义
dir /data/redis/redis6380/tmp
#设置redis密码
requirepass 123456
#主从同步master的密码
masterauth 123456
#多了这一行，用于追随某个节点的redis，被追随的节点为主节点，追随的为从节点，Redis5.0前版本可使用slaveof
replicaof 127.0.0.1 6379
```

##### 3.1.2 redis6380 配置Sentinel(哨兵)

```
#修改Sentinel监听端口
port 26380
#允许Sentinel后台运行
daemonize yes
#设置Sentinel日志存放路径
logfile "/data/redis/log/redis_26380_sentinel.log"
#工作目录，需要创建好目录,可自定义
dir /data/redis/redis6380/tmp
#Sentinel监听redis主节点,redis01：master名称可自定义,127.0.0.1 6379 ：redis主节点IP和端口,2 ：表示多少个Sentinel认为redis主节点失效时，才算真正失效
sentinel monitor redis01 127.0.0.1 6379 2
#配置失效时间，master会被这个sentinel主观地认为是不可用的，单位毫秒   
sentinel down-after-milliseconds redis01 10000
#若sentinel在该配置值内未能完成master/slave自动切换，则认为本次failover失败。
sentinel failover-timeout redis01 60000
#在发生failover主备切换时最多可以有多少个slave同时对新的master进行同步。
sentinel parallel-syncs redis01 2
#设置连接master和slave时的密码，注意的是sentinel不能分别为master和slave设置不同的密码，因此master和slave的密码应该设置相同
sentinel auth-pass redis01 123456

```

#### 3.2 redis6381

##### 3.1.1 redis6381配置redis.conf

```
cd /data/redis/redis6381
mkdir tmp
vi redis.conf
```

配置信息(和redis6379差不多，多了最后一行)：

```
#表示redis允许所有地址连接。默认127.0.0.1，仅允许本地连接。
bind 0.0.0.0
#允许redis后台运行
daemonize yes
#设置redis日志存放路径
logfile "/data/redis/log/redis_6381.log"
#设置为no，允许外部网络访问
protected-mode no
#修改redis监听端口(可以自定义)
port 6381
#pid存放目录
pidfile /var/run/redis_6381.pid
#工作目录，需要创建好目录,可自定义
dir /data/redis/redis6381/tmp
#设置redis密码
requirepass 123456
#主从同步master的密码
masterauth 123456
#多了这一行，用于追随某个节点的redis，被追随的节点为主节点，追随的为从节点，Redis5.0前版本可使用slaveof
replicaof 127.0.0.1 6379
```

##### 3.1.2 redis6380 配置Sentinel(哨兵)

```
#修改Sentinel监听端口
port 26381
#允许Sentinel后台运行
daemonize yes
#设置Sentinel日志存放路径
logfile "/data/redis/log/redis_26381_sentinel.log"
#工作目录，需要创建好目录,可自定义
dir /data/redis/redis6381/tmp
#Sentinel监听redis主节点,redis01：master名称可自定义,127.0.0.1 6379 ：redis主节点IP和端口,2 ：表示多少个Sentinel认为redis主节点失效时，才算真正失效
sentinel monitor redis01 127.0.0.1 6379 2
#配置失效时间，master会被这个sentinel主观地认为是不可用的，单位毫秒   
sentinel down-after-milliseconds redis01 10000
#若sentinel在该配置值内未能完成master/slave自动切换，则认为本次failover失败。
sentinel failover-timeout redis01 60000
#在发生failover主备切换时最多可以有多少个slave同时对新的master进行同步。
sentinel parallel-syncs redis01 2
#设置连接master和slave时的密码，注意的是sentinel不能分别为master和slave设置不同的密码，因此master和slave的密码应该设置相同
sentinel auth-pass redis01 123456
```

### 4.启动Redis集群

#### 4.1.启动redis集群,顺序主->从

```
/data/redis/redis6379/src/redis-server /data/redis/redis6379/redis.conf
/data/redis/redis6380/src/redis-server /data/redis/redis6380/redis.conf
/data/redis/redis6381/src/redis-server /data/redis/redis6381/redis.conf
```

查看启动是否成功,如果失败可以看下log文件夹下的日志

```
ps aux | grep redis
```

![image.png](https://b3logfile.com/file/2021/09/image-c6335410.png)

查看一下集群信息

```
#切换到主库目录下
cd /data/redis/redis6379/src
#连接redis
./redis-cli 
#验证密码
auth 123456
```

![image.png](https://b3logfile.com/file/2021/09/image-c0e32138.png)

```
#查看集群
info replication
```

![image.png](https://b3logfile.com/file/2021/09/image-de6ebe81.png)

#### 4.2.启动哨兵,顺序主->从

```
/data/redis/redis6379/src/redis-sentinel /data/redis/redis6379/sentinel.conf
/data/redis/redis6380/src/redis-sentinel /data/redis/redis6380/sentinel.conf
/data/redis/redis6381/src/redis-sentinel /data/redis/redis6381/sentinel.conf
```

查看启动是否成功,如果失败可以看下log文件夹下的日志

```
ps aux | grep redis
```

![image.png](https://b3logfile.com/file/2021/09/image-e41c7572.png)

### 5.启动完成后进行测试

#### 5.1测试主从数据是否同步

设置主库一个key

```
set name 小明
```

![image.png](https://b3logfile.com/file/2021/09/image-ff5dc06c.png)

再查看两个从库key是否同步过来

```
get name
```

![image.png](https://b3logfile.com/file/2021/09/image-5d7172d6.png)

![image.png](https://b3logfile.com/file/2021/09/image-d14db8ea.png)

可以看到三个实例数据已经同步。

主从测试通过。

#### 5.2测试哨兵机制

* 测试方式:模拟挂掉6379 主库，看哨兵是否会进行自动选举成为主库(master)

kill掉主库

```
#查询主库进程id
ps aux | grep redis
#kill
kill -9 18183
```

![image.png](https://b3logfile.com/file/2021/09/image-fa1da4e5.png)

接下来查看一下26380的哨兵日志

```
tail -200 /data/redis/log/redis_26380_sentinel.log
```

![image.png](https://b3logfile.com/file/2021/09/image-61a647c4.png)

简单分析如下:

哨兵检测到主库挂掉，于是26380和26381两个哨兵会进行选举，最终6381成为新的主库。

再看下集群状态

```
info replication
```

![image.png](https://b3logfile.com/file/2021/09/image-0a9e1b34.png)

可以看到6381已成为主库，因为6379挂了，所以从库目前只有6380一个。

我们再把6379启动起来，再看一下集群状态

![image.png](https://b3logfile.com/file/2021/09/image-dff8ad50.png)

可以看到6379已经上线，并是一个从库。

redis一主两从三哨兵，整个配置+测试流程已经完成。
