title: centos 7 firewall(防火墙)开放关闭端口
date: '2020-04-01 12:48:29'
updated: '2020-04-03 15:51:09'
tags: [centos]
permalink: /articles/2020/04/01/1585716509461.html
---
### 1.firewall的基本启动/停止/重启命令

```
#centos7启动防火墙
systemctl start firewalld.service
#centos7停止防火墙/关闭防火墙
systemctl stop firewalld.service
#centos7重启防火墙
systemctl restart firewalld.service

#设置开机启用防火墙
systemctl enable firewalld.service
#设置开机不启动防火墙
systemctl disable firewalld.service
```

### 2.新增开放一个端口号

```
firewall-cmd --zone=public --add-port=80/tcp --permanent
#说明:
#–zone 作用域
#–add-port=80/tcp #添加端口，格式为：端口/通讯协议
#–permanent 永久生效，没有此参数重启后失效

#多个端口:
firewall-cmd --zone=public --add-port=80-90/tcp --permanent
```

注意:新增/删除操作需要重启防火墙服务.

其他PC telnet开放的端口必须保证本地 telnet 127.0.0.1 端口号 能通。本地不通不一定是防火墙的问题。

查看本机已经启用的监听端口:

```
#centos7以下使用netstat -ant,7使用ss
ss -ant
```

### 3.查看

```
#centos7查看防火墙所有信息
firewall-cmd --list-all
#centos7查看防火墙开放的端口信息
firewall-cmd --list-ports
```

### 4.删除

```
firewall-cmd --zone=public --remove-port=80/tcp --permanent
```
