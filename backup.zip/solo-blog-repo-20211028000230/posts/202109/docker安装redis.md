title: docker 安装redis
date: '2021-09-10 16:24:43'
updated: '2021-09-10 16:24:43'
tags: [Redis]
permalink: /articles/2021/09/10/1631262283650.html
---
1、获取 redis 镜像

```
docker pull redis
```

![](https://b3logfile.com/file/2021/09/solo-fetchupload-5388086499624202735-7632c9dc.png)

2、查看本地镜像

```
docker images
```

![](https://b3logfile.com/file/2021/09/solo-fetchupload-6419299988850761143-eb48dc74.png)

3、从官网获取 [redis.conf](http://download.redis.io/redis-stable/redis.conf) 配置文件

```
cd /usr/local/docker   //进入目录
wget http://download.redis.io/redis-stable/redis.conf   //下载redis配置文件
vim redis.conf  //修改配置文件
```

* bind 127.0.0.1 #注释掉这部分，这是限制redis只能本地访问
* protected-mode no #默认yes，开启保护模式，限制为本地访问
* daemonize no#默认no，改为yes意为以守护进程方式启动，可后台运行，除非kill进程（可选），改为yes会使配置文件方式启动redis失败
* dir  ./ #输入本地redis数据库存放文件夹（可选）
* appendonly yes #redis持久化（可选）
* requirepass xxxxx #设置redis密码

![](https://b3logfile.com/file/2021/09/solo-fetchupload-4840250971519952796-0da2be34.png)

3、docker 启动 redis

```
docker run -p 3680:3680 --name redis -v /usr/local/docker/redis.conf:/etc/redis/redis.conf -v /usr/local/dockr/data:/data -d redis redis-server /etc/redis/redis.conf --appendonly yes
```

* -p 6380:6380 端口映射：前表示主机部分，：后表示容器部分。
* --name myredis  指定该容器名称，查看和进行操作都比较方便。
* -v 挂载目录，规则与端口映射相同。
* -d redis 表示后台启动redis
* redis-server /etc/redis/redis.conf  以配置文件启动redis，加载容器内的conf文件，最终找到的是挂载的目录/usr/local/docker/redis.conf
* appendonly yes 开启redis 持久化

![](https://b3logfile.com/file/2021/09/solo-fetchupload-2320665266894487732-9e74cf35.png)

4、查看redis状态

![](https://b3logfile.com/file/2021/09/solo-fetchupload-8710924051765228430-3eba8f7d.png)

5、进入redis

```
docker exec -it redis /bin/bash
```

![](https://b3logfile.com/file/2021/09/solo-fetchupload-4526948046991913437-5b6be275.png)
