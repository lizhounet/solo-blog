title: windows 下MYSQL 8 忘记密码重置密码
date: '2020-11-17 13:42:49'
updated: '2020-11-17 13:54:32'
tags: [mysql]
permalink: /articles/2020/11/17/1605591769796.html
---
参考 https://www.cnblogs.com/wangjiming/p/10363357.html

### cmd进入mysql安装目录

![image.png](https://b3logfile.com/file/2020/11/image-ca4beb35.png)

### 停止mysql服务

```
net stop mysql
```

![image.png](https://b3logfile.com/file/2020/11/image-4ab5374c.png)

### 无密码启动

```
mysqld --console --skip-grant-tables --shared-memory
```

![image.png](https://b3logfile.com/file/2020/11/image-7e2847c3.png)

### 另启一个dos窗口，无密码登录

执行

```
mysql -u root
```

![image.png](https://b3logfile.com/file/2020/11/image-479a17da.png)

依次执行

```
flush privileges;--刷新权限

alter user root@localhost identified by '000000'--修改密码
```

![image.png](https://b3logfile.com/file/2020/11/image-ca3f5a90.png)

### 关闭另一个dos窗口，然后启动mysql服务

![image.png](https://b3logfile.com/file/2020/11/image-f519723d.png)

### 然后就可以重新使用新密码登陆了

![image.png](https://b3logfile.com/file/2020/11/image-c7167cac.png)
