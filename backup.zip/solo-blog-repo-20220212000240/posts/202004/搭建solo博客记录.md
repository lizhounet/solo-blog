title: 搭建solo博客记录
date: '2020-04-01 18:28:16'
updated: '2021-03-18 11:04:38'
tags: [Solo, 个人博客]
permalink: /articles/2020/04/01/1585736895879.html
---
![](https://img.hacpai.com/bing/20180420.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 前言:

本来我的博客是自研(vue+.net core 2.1+mysql)[旧版博客](https://blog.zhouli.info)，当初选择自研说白了为了过下技隐😄 (当然还为了学习巩固技术),后来觉得当时选的模板太丑啦，又不想也没有必要再去自己开发一套了，于是决定不造轮子了，后来选择了 小而美的solo博客系统

下面记录一下搭建solo博客的过程
我的服务器是阿里云最低配ECS服务器(centos) 当时活动直接买的三年

进入正题
参考文档(写得比较详细):https://hacpai.com/article/1565021959471#toc_h2_14

### 1.安装 docker

官方文档:[https://docs.docker.com/engine/install/centos/](https://docs.docker.com/engine/install/centos/)

```
#卸载旧版本
yum remove docker \
                  docker-client \
                  docker-client-latest \
                  docker-common \
                  docker-latest \
                  docker-latest-logrotate \
                  docker-logrotate \
                  docker-engine

# 安装yum-utils软件包
yum install -y yum-utils

#设置Docker仓库（这里使用阿里云地址）
yum-config-manager \
    --add-repo \
    http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo

#更新yum软件包索引
yum makecache fast 
			#centos8没有该参数去掉fast参数，就可以了
			#yum makecache
#yum安装docker
#yum -y install docker
yum install docker-ce docker-ce-cli containerd.io

#设置docker开机自启
systemctl enable docker

#启动docker
systemctl start docker
```

### 2.安装mysql

这里由于我的服务器已经安装了mysql,所以没有使用docker再次安装
下面是docker安装mysql教程:

```
# 安装mysql:5.6,直接docker run 他会自动去官方镜想下载


docker run --restart always --name mysql -p 3306:3306 -e MYSQL_ROOT_PASSWORD=123456 -d mysql:5.6
# MYSQL_ROOT_PASSWORD=你的数据库密码
#--restart always 设置mysql容器自启动
#-p 3306:3306 左边端口为服务器端口，右边端口为容器mysql端口，意思就是:容器内部端口3306端口映射到主机的3306端口


# docker安装的mysql默认允许远程连接，可以使用Navicat等软件连接数据库
# 进入容器mysql
docker exec -it mysql bash

# 进入数据库 p后面跟你的密码
mysql -uroot -pXXX

# 创建数据库(数据库名:solo;字符集utf8mb4;排序规则utf8mb4_general_ci)
create database solo DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
# 出现Query OK, 1 row affected (0.00 sec)表示成功
#退出数据库
exit
#退出容器
exit
```

### 3.安装 solo

```
docker run --detach --restart always --name solo --network=host \
--env RUNTIME_DB="MYSQL" \
--env JDBC_USERNAME="root" \
--env JDBC_PASSWORD="123456" \
--env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
--env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
b3log/solo --listen_port=8080 --server_scheme=https --server_host=47.240.170.145
```

上面的命令建议手敲，免得出错，参数说明

* `--restart always` 设置solo容器自启动
* `--env JDBC_PASSWORD="123456"` 将 123456 换成你的密码
* `--listen_port=8080` solo监听的端口
* `--server_scheme=http` 请求方式，我使用https，因为我下一步就使用nginx配置https
* `--server_host=www.jinjianh.com` 你的域名，如果你没有域名可以写 ip 地址
* `--rm` 容器停止会自动删除该容器(上面命令我没有使用)。

### 4. 安装 nginx

由于我的服务器也是安装了nginx的，也没有采用docker再次安装
具体可以看 https://hacpai.com/article/1565021959471#8--%E5%AE%89%E8%A3%85nginx
安装后就开始配置nginx
贴下我的配置:

```
server
{
    listen 80;
	listen 443 ssl http2;
    server_name www.zhouli.info;
  
    #SSL-START SSL相关配置，请勿删除或修改下一行带注释的404规则
    #error_page 404/404.html;
    #HTTP_TO_HTTPS_START
    if ($server_port !~ 443){
        rewrite ^(/.*)$ https://$host$1 permanent;
    }
    #HTTP_TO_HTTPS_END
    ssl_certificate    /var/zhouli/sshnginx/www.zhouli.info.pem;
    ssl_certificate_key    /var/zhouli/sshnginx/file.zhouli.info.key;
    ssl_protocols TLSv1 TLSv1.1 TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:HIGH:!aNULL:!MD5:!RC4:!DHE;
    ssl_prefer_server_ciphers on;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    error_page 497  https://$host$request_uri;
  
    #SSL-END
     location / 
     {
  	      proxy_set_header  Host $http_host;  
              proxy_set_header  X-Real-IP $remote_addr;  
              client_max_body_size  10m;  
              proxy_pass http://47.102.105.169:8080;
     }
}
```

下面重启nginx

如果nginx安装在服务器本身就执行 `systemctl restart nginx`
如果nginx运行在docker中 `docker restart nginx`
完毕！！！！！！！！
看一下效果：
![TIM图片20200401185337.png](https://img.hacpai.com/file/2020/04/TIM图片20200401185337-c2174fae.png)

