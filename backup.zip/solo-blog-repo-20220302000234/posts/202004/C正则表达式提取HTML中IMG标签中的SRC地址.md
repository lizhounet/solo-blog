title: C#正则表达式提取HTML中IMG标签中的SRC地址
date: '2020-04-01 13:12:11'
updated: '2020-04-01 13:12:11'
tags: [C#, 正则表达式]
permalink: /articles/2020/04/01/1585717931040.html
---

```
    /// <summary>   
    /// 取得HTML中所有图片的 URL。   
    /// </summary>   
    /// <param name="sHtmlText">HTML代码</param>   
    /// <returns>图片的URL列表</returns>   
    public static string[] GetHtmlImageUrlList(string sHtmlText)   
    {   
      // 定义正则表达式用来匹配 img 标签   
      Regex regImg = new Regex(@"<img\b[^<>]*?\bsrc[\s\t\r\n]*=[\s\t\r\n]*[""']?[\s\t\r\n]*(?<imgUrl>[^\s\t\r\n""'<>]*)[^<>]*?/?[\s\t\r\n]*>",   RegexOptions.IgnoreCase);   
      // 搜索匹配的字符串   
      MatchCollection matches = regImg.Matches(sHtmlText);   
      int i = 0;   
      string[] sUrlList = new string[matches.Count];   
      // 取得匹配项列表   
      foreach (Match match in matches)   
      sUrlList[i++] = match.Groups["imgUrl"].Value;   
      return sUrlList;   
    }  
```
