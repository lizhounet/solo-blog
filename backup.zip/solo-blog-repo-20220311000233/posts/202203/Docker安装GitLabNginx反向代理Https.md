title: Docker安装GitLab，Nginx反向代理Https
date: '2022-03-09 18:15:19'
updated: '2022-03-09 18:15:19'
tags: [gitlab, nginx, ssl]
permalink: /articles/2022/03/09/1646820919539.html
---
### 一、安装环境

* 操作系统：CentOS8.0
* Web服务：nginx/1.12.0
* Docker服务：docker/1.7.1

安装GitLab前请确保以上环境都已安装

### 二、在宿主机创建数据存放目录

```
mkdir /data/gitlab & cd /data/gitlab 
mkdir config logs data
```

为了方便修改配置和后期维护，需要新建config、logs、data这三个子栏目来映射到docker里面的gitlab服务下的目录

### 三、拉取gitlab镜像并启动容器
```
docker pull gitlab/gitlab-ce:latest
docker run --detach \
 --hostname gitlab.example.cn \
 --publish 20443:443 \
 --publish 20080:80 \
 --publish 20022:22 \
 --name gitlab \
 --restart always\
 --volume /srv/gitlab/config:/etc/gitlab \
 --volume /srv/gitlab/logs:/var/log/gitlab \
 --volume /srv/gitlab/data:/var/opt/gitlab \
 gitlab/gitlab-ce:latest
```

这里其实可以不用执行docker pull，执行docker run的时候如果没有对应的image则会自动执行pull来获取image

### 四、修改gitlab配置文件启用https支持

```
cd /data/gitlab/config
cp /data/wwwroot/crtkey/gitlab.crt gitlab.crt
cp /data/wwwroot/crtkey/gitlab.key gitlab.key
vim gitlab.rb
```

gitlab.crt和gitlab.key是你绑定域名的ssl下发的秘钥和证书，需要另外自己申请

开启gitlab.rb如下配置

```
external_url 'https://gitlab.example.cn'nginx
['redirect_http_to_https'] = true
gitlab_rails['gitlab_shell_ssh_port'] = 20022 # 此端口是run时22端口映射的20022端口
nginx['ssl_certificate'] = "/etc/gitlab/ssl/gitlab.crt"
nginx['ssl_certificate_key'] = "/etc/gitlab/ssl/gitlab.key"
```

保存配置文件，重启容器

```
docker restart gitlab
```

### 五、配置Nginx反向代理

添加配置信息在nginx对应站点的conf中

```
## 将HTTP请求全部重定向至HTTPS
server {
    listen       80;
    server_name  gitlab.huijifood.com;
    charset utf-8;
    access_log  /data/nginx/logs/gitlab.access.log;
    error_log  /data/nginx/logs/gitlab.error.log;
    rewrite ^ https://gitlab.huijifood.com;
}

## 请求转发到GitLab容器
server {
    listen       443 ssl;
    server_name  gitlab.huijifood.com;
    charset utf-8;
    access_log  /data/nginx/logs/gitlab.access.log;
    error_log  /data/nginx/logs/gitlab.error.log;
    ssl on;
    ssl_certificate         /data/gitlab/config/ssl/gitlab.huijifood.com.crt;
    ssl_certificate_key     /data/gitlab/config/ssl/gitlab.huijifood.com.key;
    ssl_session_timeout     10m;
    ssl_session_cache       shared:SSL:10m; 
    location / {
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto https;
    proxy_pass    https://127.0.0.1:20443;#注意这里的20443端口
    }
}
```

```
service nginx restart  #重启服务
```

试试能不能访问

