title: gitlab cicd 部署 dotnet .net core
date: '2022-03-18 11:36:55'
updated: '2022-03-24 14:33:59'
tags: [cicd, gitlab]
permalink: /articles/2022/03/18/1647574615249.html
---
# 环境

两台服务器：
A(运行gitlab，gitlab runner)，需要安装docker，gitlab，gitlab runner
B(用来运行dotnet应用)，需要安装docker，dotnet应用通过docker运行
gitlab安装：[Docker安装GitLab，Nginx反向代理Https (zhouli.info)](https://zhouli.info/articles/2022/03/09/1646820919539.html)

# 整体流程

1. 准备一个在gitlab上的项目(不限语言,本文demo是.net core 的项目)，里面编写好Dockerfile脚本，用来打包docker镜像。
2. 编写.gitlab-ci.yml文件，内容是打包docker镜像并上传镜像到私有仓库
3. 应用服务器拉取镜像并启动

# 开始

## 1.准备项目

![image.png](https://b3logfile.com/file/2022/03/image-ea4f014b.png)

## 2.安装注册gitlab-runner

```
docker run -d --name gitlab-runner --restart always \
   -v /data/gitlab-runner/config:/etc/gitlab-runner \
   -v /var/run/docker.sock:/var/run/docker.sock \
   -v /bin/docker:/bin/docker \
   gitlab/gitlab-runner:v14.8.0
```

* 因为gitlab-runner 需要执行宿主机的docker命令，所以需要挂载/bin/docker:/bin/docker  目录
* docker容器内执行docker命令提示Got permission denied while trying to connect to the Docker 没有权限执行docker命令，请看博客https://blog.csdn.net/bpqdwo/article/details/93714482

![image.png](https://b3logfile.com/file/2022/03/image-c3a6a020.png)
进入容器，注册gitlab-runner到自己的gitlab上面

```
docker exec -it gitlab-runner bash

gitlab-runner register \
  --non-interactive \
  --executor "shell" \
  --url "https://gitlab.huijifood.com/" \
  --registration-token "tgvKNQByC9tyEiS_GrZ-" \
  --description "huiji-runner" \
  --tag-list "build,deploy" \
  --run-untagged="true" \
  --locked="false" \
```

说明：

| 参数               | 说明                 |
| ------------------ | -------------------- |
| non-interactive    | 非交互式注册         |
| executor           | 执行器               |
| url                | gitlab的地址         |
| registration-token | gitlab-ci的Toekn     |
| description        | 描述                 |
| tag-list           | gitlab-runner的标签  |
| run-untagged       | 是否运行未标记的任务 |
| locked             | 是否锁定             |

显示成功

![image.png](https://b3logfile.com/file/2022/03/image-ac30ed82.png)
看下gitlab-runner,注册成功
![image.png](https://b3logfile.com/file/2022/03/image-03477332.png)

## 3.编写.gitlab-ci.yml

```
before_script:
    - export BULIDTIME=$(date "+%G%m%d")
variables:
    ALI_REGISTRY_USER: $ALI_REGISTRY_USER
    ALI_REGISTRY_PASSWORD: $ALI_REGISTRY_PASSWORD
    ALI_REGISTRY: $ALI_REGISTRY
stages:
    - build
    - deploy

build:
    stage: build
    only:
    - tags
    - master
    - /^release-.*$/
    - /^hotfix-.*$/
    script:
        - "pwd"
        - "echo 组名：${GROUP_NAME}"
        - "echo 包含项目名称的命名空间：${CI_PROJECT_PATH}"
        - "echo 项目的命名空间（组名或用户名）：${CI_PROJECT_NAMESPACE}"
        - "echo 项目名称（网页上显示的）：${CI_PROJECT_TITLE}"
        - "echo 分支:${CI_COMMIT_REF_NAME}"
        - "echo 流水线运行时间：${CI_PIPELINE_CREATED_AT}"
        - "docker build -f ./dotnet-cicd-demo/Dockerfile -t ${ALI_REGISTRY}/${CI_PROJECT_PATH}:${CI_COMMIT_REF_NAME}-${BULIDTIME} ."

deploy:
    stage: deploy
    only:
    - tags
    - master
    - /^release-.*$/
    - /^hotfix-.*$/
    script: 
        - "docker login -u ${ALI_REGISTRY_USER} -p ${ALI_REGISTRY_PASSWORD} ${ALI_REGISTRY}"
        - "docker push ${ALI_REGISTRY}/${CI_PROJECT_PATH}:${CI_COMMIT_REF_NAME}-${BULIDTIME}"
        - "docker image rm ${ALI_REGISTRY}/${CI_PROJECT_PATH}:${CI_COMMIT_REF_NAME}-${BULIDTIME}"
        - "echo 发布成功"
```

本配置文件只定义了两个作业，build作业用来打包docker镜像，deploy作业用来上传镜像到私有仓库，没有做后续的部署到线上的操作，可以自己扩展(比如通过ssh连接应用服务器，从私有仓库拉取该镜像，运行docker容器，来实现部署)

## 4.看下效果

### 流水线运行完成

![image.png](https://b3logfile.com/file/2022/03/image-3b9ddb1d.png)

![image.png](https://b3logfile.com/file/2022/03/image-73aa971f.png)

### 查看阿里镜像仓库，容器镜像已经上传上来了

![image.png](https://b3logfile.com/file/2022/03/image-21ae2c99.png)

### 拉取镜像启动容器

```
docker run -d -p 9999:80 --name dotnet-cicd-demo registry.cn-chengdu.aliyuncs.com/huiji-repository/dotnet-cicd-demo:master-20220324
```

![image.png](https://b3logfile.com/file/2022/03/image-ec037f74.png)

### 访问

![image.png](https://b3logfile.com/file/2022/03/image-9f572722.png)

